-- phpMyAdmin SQL Dump
-- version 2.11.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 28, 2008 at 01:19 PM
-- Server version: 5.0.45
-- PHP Version: 5.2.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `heed_development`
--

-- --------------------------------------------------------

--
-- Table structure for table `actions`
--

CREATE TABLE IF NOT EXISTS `actions` (
  `id` int(11) NOT NULL auto_increment,
  `district_id` int(11) default NULL,
  `article_id` int(11) default NULL,
  `house` varchar(2) NOT NULL,
  `action` text,
  `created_at` datetime default NULL,
  `processed` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `actions`
--


-- --------------------------------------------------------

--
-- Table structure for table `articles`
--

CREATE TABLE IF NOT EXISTS `articles` (
  `id` int(11) NOT NULL auto_increment,
  `tom_id` varchar(20) default NULL,
  `district_id` int(11) NOT NULL,
  `article_type_id` int(11) NOT NULL default '1',
  `title` varchar(420) NOT NULL,
  `summary` text NOT NULL,
  `text` text NOT NULL,
  `stage` tinyint(4) NOT NULL default '1',
  `cost` decimal(20,2) default NULL,
  `version` int(11) NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `articles`
--


-- --------------------------------------------------------

--
-- Table structure for table `articles_supporters`
--

CREATE TABLE IF NOT EXISTS `articles_supporters` (
  `id` int(11) NOT NULL auto_increment,
  `article_id` int(11) NOT NULL,
  `article_version` int(11) default NULL,
  `supporter_id` int(11) NOT NULL,
  `supporter_type` varchar(30) NOT NULL,
  `created_at` datetime NOT NULL,
  `ended_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `articles_supporters`
--


-- --------------------------------------------------------

--
-- Table structure for table `article_types`
--

CREATE TABLE IF NOT EXISTS `article_types` (
  `id` int(11) NOT NULL auto_increment,
  `district_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `short_name` varchar(20) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `article_types`
--


-- --------------------------------------------------------

--
-- Table structure for table `article_versions`
--

CREATE TABLE IF NOT EXISTS `article_versions` (
  `id` int(11) NOT NULL auto_increment,
  `article_id` int(11) NOT NULL,
  `district_id` int(11) NOT NULL,
  `title` varchar(420) default NULL,
  `summary` text,
  `text` text,
  `cost` decimal(20,2) default NULL,
  `stage` tinyint(4) NOT NULL,
  `version` int(11) NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `article_versions`
--


-- --------------------------------------------------------

--
-- Table structure for table `badges_privileges`
--

CREATE TABLE IF NOT EXISTS `badges_privileges` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(50) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `badges_privileges`
--

INSERT INTO `badges_privileges` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'manage badges', '2008-05-26 11:16:07', '2008-05-26 11:16:07'),
(2, 'manage districts', '2008-05-26 11:16:07', '2008-05-26 11:16:07'),
(3, 'create articles', '2008-05-26 11:16:07', '2008-05-26 11:16:07'),
(4, 'edit article', '2008-05-26 11:16:07', '2008-05-26 11:16:07'),
(5, 'finalize article', '2008-05-26 11:16:07', '2008-05-26 11:16:07'),
(6, 'progress article', '2008-05-26 11:16:07', '2008-05-26 11:16:07'),
(7, 'support articles', '2008-05-26 11:16:07', '2008-05-26 11:16:07'),
(8, 'manage pages', '2008-05-26 11:16:07', '2008-05-26 11:16:07'),
(9, 'rate comments', '2008-05-26 11:16:07', '2008-05-26 11:16:07');

-- --------------------------------------------------------

--
-- Table structure for table `badges_roles`
--

CREATE TABLE IF NOT EXISTS `badges_roles` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(50) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `badges_roles`
--

INSERT INTO `badges_roles` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'authenticated', '2008-05-26 11:16:07', '2008-05-26 11:16:07'),
(2, 'admin', '2008-05-26 11:16:07', '2008-05-26 11:16:07'),
(3, 'registered_voter', '2008-05-26 11:16:07', '2008-05-26 11:16:07'),
(4, 'group_owner', '2008-05-26 11:16:07', '2008-05-26 11:16:07'),
(5, 'group_member', '2008-05-26 11:16:07', '2008-05-26 11:16:07'),
(6, 'article_owner', '2008-05-26 11:16:07', '2008-05-26 11:16:07'),
(7, 'representative', '2008-05-26 11:16:07', '2008-05-26 11:16:07');

-- --------------------------------------------------------

--
-- Table structure for table `badges_role_privileges`
--

CREATE TABLE IF NOT EXISTS `badges_role_privileges` (
  `id` int(11) NOT NULL auto_increment,
  `role_id` int(11) default NULL,
  `privilege_id` int(11) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `badges_role_privileges`
--

INSERT INTO `badges_role_privileges` (`id`, `role_id`, `privilege_id`, `created_at`, `updated_at`) VALUES
(1, 2, 1, '2008-05-26 11:16:07', '2008-05-26 11:16:07'),
(2, 2, 2, '2008-05-26 11:16:07', '2008-05-26 11:16:07'),
(16, 7, 6, '2008-05-26 11:40:42', '2008-05-26 11:40:42'),
(15, 6, 5, '2008-05-26 11:40:41', '2008-05-26 11:40:41'),
(14, 6, 4, '2008-05-26 11:40:41', '2008-05-26 11:40:41'),
(13, 4, 8, '2008-05-26 11:40:41', '2008-05-26 11:40:41'),
(12, 3, 9, '2008-05-26 11:40:41', '2008-05-26 11:40:41'),
(11, 3, 7, '2008-05-26 11:40:41', '2008-05-26 11:40:41'),
(10, 3, 3, '2008-05-26 11:40:41', '2008-05-26 11:40:41');

-- --------------------------------------------------------

--
-- Table structure for table `badges_user_roles`
--

CREATE TABLE IF NOT EXISTS `badges_user_roles` (
  `id` int(11) NOT NULL auto_increment,
  `user_id` int(11) default NULL,
  `role_id` int(11) default NULL,
  `authorizable_type` varchar(30) default NULL,
  `authorizable_id` int(11) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `badges_user_roles`
--

INSERT INTO `badges_user_roles` (`id`, `user_id`, `role_id`, `authorizable_type`, `authorizable_id`, `created_at`, `updated_at`) VALUES
(1, 1, 1, NULL, NULL, '2008-05-26 11:27:26', '2008-05-26 11:27:26'),
(2, 1, 2, NULL, NULL, '2008-05-26 11:34:24', '2008-05-26 11:34:24'),
(3, 2, 1, NULL, NULL, '2008-05-26 11:42:59', '2008-05-26 11:42:59'),
(4, 3, 1, NULL, NULL, '2008-05-28 01:48:27', '2008-05-28 01:48:27');

-- --------------------------------------------------------

--
-- Table structure for table `comites`
--

CREATE TABLE IF NOT EXISTS `comites` (
  `id` int(11) NOT NULL auto_increment,
  `district_id` int(11) default NULL,
  `name` varchar(255) default NULL,
  `tom_id` varchar(6) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `comites`
--


-- --------------------------------------------------------

--
-- Table structure for table `comite_stages`
--

CREATE TABLE IF NOT EXISTS `comite_stages` (
  `id` int(11) NOT NULL auto_increment,
  `comite_id` int(11) NOT NULL,
  `article_id` int(11) NOT NULL,
  `status_code` int(11) NOT NULL default '0',
  `ended_at` datetime default NULL,
  `created_at` datetime NOT NULL,
  `house_stage` tinyint(4) default NULL,
  `senate_stage` tinyint(4) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `comite_stages`
--


-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(11) NOT NULL auto_increment,
  `category_code` tinyint(4) NOT NULL default '0',
  `title` varchar(500) default NULL,
  `comment` text,
  `created_at` datetime NOT NULL,
  `commentable_id` int(11) NOT NULL default '0',
  `commentable_type` varchar(15) NOT NULL default '',
  `user_id` int(11) default '0',
  PRIMARY KEY  (`id`),
  KEY `fk_comments_user` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `comments`
--


-- --------------------------------------------------------

--
-- Table structure for table `districts`
--

CREATE TABLE IF NOT EXISTS `districts` (
  `id` int(11) NOT NULL auto_increment,
  `parent_id` int(11) NOT NULL default '0',
  `name` varchar(255) NOT NULL,
  `tax_population` int(11) NOT NULL default '1',
  `district_residences_count` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `districts`
--

INSERT INTO `districts` (`id`, `parent_id`, `name`, `tax_population`, `district_residences_count`) VALUES
(1, 0, 'Real Democracy', 1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `district_residences`
--

CREATE TABLE IF NOT EXISTS `district_residences` (
  `id` int(11) NOT NULL auto_increment,
  `user_id` int(11) NOT NULL,
  `district_id` int(11) NOT NULL,
  `start_date` datetime NOT NULL,
  `end_date` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `district_residences`
--

INSERT INTO `district_residences` (`id`, `user_id`, `district_id`, `start_date`, `end_date`) VALUES
(1, 2, 1, '2008-05-26 11:42:59', NULL),
(2, 3, 1, '2008-05-28 01:48:27', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `endorsements`
--

CREATE TABLE IF NOT EXISTS `endorsements` (
  `id` int(11) NOT NULL auto_increment,
  `article_id` int(11) default NULL,
  `user_id` int(11) default NULL,
  `created_at` datetime NOT NULL,
  `ended_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `endorsements`
--


-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE IF NOT EXISTS `groups` (
  `id` int(11) NOT NULL auto_increment,
  `district_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `tagline` varchar(255) NOT NULL,
  `created_on` datetime NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `groups`
--


-- --------------------------------------------------------

--
-- Table structure for table `group_memberships`
--

CREATE TABLE IF NOT EXISTS `group_memberships` (
  `id` int(11) NOT NULL auto_increment,
  `group_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `group_memberships`
--


-- --------------------------------------------------------

--
-- Table structure for table `interests`
--

CREATE TABLE IF NOT EXISTS `interests` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `interests`
--


-- --------------------------------------------------------

--
-- Table structure for table `legislations`
--

CREATE TABLE IF NOT EXISTS `legislations` (
  `id` int(11) NOT NULL auto_increment,
  `article_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `closing_time` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `legislations`
--


-- --------------------------------------------------------

--
-- Table structure for table `mailing_lists`
--

CREATE TABLE IF NOT EXISTS `mailing_lists` (
  `id` int(11) NOT NULL auto_increment,
  `email` varchar(255) NOT NULL,
  `zip` varchar(10) NOT NULL,
  `created_on` datetime NOT NULL,
  `active` tinyint(1) NOT NULL default '1',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mailing_lists`
--


-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE IF NOT EXISTS `notifications` (
  `id` int(11) NOT NULL auto_increment,
  `user_id` int(11) NOT NULL,
  `message` varchar(880) NOT NULL,
  `status_code` tinyint(4) NOT NULL default '1',
  `created_at` datetime NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `notifications`
--


-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE IF NOT EXISTS `pages` (
  `id` int(11) NOT NULL auto_increment,
  `version` int(11) NOT NULL,
  `title` varchar(255) default NULL,
  `content` text,
  `lock_version` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `pages`
--


-- --------------------------------------------------------

--
-- Table structure for table `page_relationships`
--

CREATE TABLE IF NOT EXISTS `page_relationships` (
  `id` int(11) NOT NULL auto_increment,
  `page_id` int(11) default NULL,
  `pagable_id` int(11) default NULL,
  `pagable_type` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `page_relationships`
--


-- --------------------------------------------------------

--
-- Table structure for table `page_versions`
--

CREATE TABLE IF NOT EXISTS `page_versions` (
  `id` int(11) NOT NULL auto_increment,
  `page_id` int(11) default NULL,
  `version` int(11) default NULL,
  `title` varchar(255) default NULL,
  `content` text,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `page_versions`
--


-- --------------------------------------------------------

--
-- Table structure for table `ratings`
--

CREATE TABLE IF NOT EXISTS `ratings` (
  `id` int(11) NOT NULL auto_increment,
  `rating` int(11) default '0',
  `created_at` datetime NOT NULL,
  `rateable_type` varchar(15) NOT NULL default '',
  `rateable_id` int(11) NOT NULL default '0',
  `user_id` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `fk_ratings_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `ratings`
--


-- --------------------------------------------------------

--
-- Table structure for table `schema_info`
--

CREATE TABLE IF NOT EXISTS `schema_info` (
  `version` int(11) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `schema_info`
--


-- --------------------------------------------------------

--
-- Table structure for table `taggings`
--

CREATE TABLE IF NOT EXISTS `taggings` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `tag_id` int(11) unsigned default NULL,
  `taggable_id` int(11) unsigned default NULL,
  `taggable_type` varchar(255) default NULL,
  `interest_id` int(11) unsigned NOT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `index_taggings_on_tag_id` (`tag_id`),
  KEY `index_taggings_on_taggable_id_and_taggable_type` (`taggable_id`,`taggable_type`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `taggings`
--


-- --------------------------------------------------------

--
-- Table structure for table `tags`
--

CREATE TABLE IF NOT EXISTS `tags` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tags`
--


-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL auto_increment,
  `login` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `crypted_password` varchar(40) NOT NULL,
  `salt` varchar(40) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `remember_token` varchar(255) NOT NULL,
  `remember_token_expires_at` datetime default NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `zip` varchar(20) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `login`, `email`, `crypted_password`, `salt`, `created_at`, `updated_at`, `remember_token`, `remember_token_expires_at`, `first_name`, `last_name`, `zip`) VALUES
(1, 'thomas', 'admin@hungrychild.org', '357daaf118ff81fae4bfbe717289c20af70816c2', '5597c5340d0437c9fcb341b5d19856b252ace4c6', '2008-05-26 11:27:26', '2008-05-26 11:41:21', '', NULL, 'Thomas', 'Jefferson', '00000'),
(2, 'drake', 'drakew@gmail.com', 'efdb6ab0cdf79036133f054a806eaa6daff5c4a4', '3d6ba7d409103a00e68a13475784af85f81a3ee5', '2008-05-26 11:42:58', '2008-05-28 12:45:46', '', NULL, 'Drake', 'Weinert', '96781'),
(3, 'peter', '2@2.n34', 'e0a6da18a263374e02a0838bdc5bc2a95c702123', '66eb6517321e23c56fa933cca72f9773b7932c83', '2008-05-28 01:48:27', '2008-05-28 02:38:54', '', NULL, 'Peter', 'Piper', '22222');

-- --------------------------------------------------------

--
-- Table structure for table `votes`
--

CREATE TABLE IF NOT EXISTS `votes` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `user_id` int(11) NOT NULL,
  `voteable_type` varchar(25) NOT NULL,
  `voteable_id` int(11) NOT NULL,
  `vote` smallint(1) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `votes`
--

